# Answer Sources in Prolog :: History

Nan.System.Sources
Nan.System.Sources/Prolog 1.2.0-beta
Answer Sources in Prolog
Copyright 2015-2017 Julio P. Di Egidio
Licensed under GNU GPLv3.
http://julio.diegidio.name/Projects/Nan.System.Sources/
https://github.com/jp-diegidio/Nan.System.Sources-Prolog/

Version 1.2.0-beta:
-------------------
- Code restructured and cleaned up.
- Code docs coverage (reasonably) completed.
- Testing coverage (reasonably) completed.
- **BREAKING**: Several breaking changes.

Version "Preview":
-----------------
- Baseline version "Preview".
